package com.pixshow.constant;

public class GameGlitter {

    public static class glitterType {
        public final static int isDefault = 0;
        public final static int isHoliday = 1;
    }

    public static class useType {
        public final static int unUse = 0;
        public final static int use   = 1;
    }

    public static class buttonType {
        public final static int url      = 1;
        public final static int info     = 2;
        public final static int download = 3;
    }
}
