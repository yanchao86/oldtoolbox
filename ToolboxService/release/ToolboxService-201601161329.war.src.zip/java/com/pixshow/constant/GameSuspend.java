package com.pixshow.constant;

public class GameSuspend {
    public static class suspendType {
        public final static int isPic       = 0;
        public final static int isRecommend = 1;
    }

    public static class useType {
        public final static int unUse = 0;
        public final static int use   = 1;
    }
    public static class buttonType {
        public final static int url      = 1;
        public final static int info     = 2;
        public final static int download = 3;
    }
}
