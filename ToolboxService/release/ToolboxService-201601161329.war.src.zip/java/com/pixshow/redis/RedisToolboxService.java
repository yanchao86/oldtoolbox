package com.pixshow.redis;

import org.springframework.stereotype.Service;

@Service
public class RedisToolboxService extends AbstractRedisService<String, String>{

    
//    public boolean check(String key) {
//        return this.check(key);
//    }
    

}